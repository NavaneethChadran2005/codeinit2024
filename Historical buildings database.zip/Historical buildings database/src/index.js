import express from "express";
import { dirname } from "path";
import { fileURLToPath } from "url";
import bodyParser from "body-parser";
import path from "path";
import { getBuilding, getBuildings, createBuildingData, searchBuilding} from "./database.js";


const __dirname = dirname(fileURLToPath(import.meta.url));

const app = express();
const port = 3000;
var building = "";
var state = "";
var city = "";
var builtin;
var builtby = "";
var imgurl = "";
var searchResults;

app.use(bodyParser.urlencoded({ extended: true }));

const staticPath = path.join(__dirname, "../public")
// Serve static files from the "public" directory
app.use(express.static(staticPath));


function fetchBuildingData(req, res, next) {
  console.log(req.body);
  building = req.body["building"];
  state = req.body["state"];
  city = req.body["city"];
  builtin = req.body["builtin"];
  builtby = req.body["builtby"];
  imgurl = req.body["imgurl"];
  next();
}

app.use(fetchBuildingData);

// app.get('/newEntry.html', (req, res) => {
//   res.sendFile(__dirname + '/public/newEntry.html');
// });

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname,"../public/index.html"));
  });
  
app.get("/entry", (req, res) => {
    res.sendFile(path.join(__dirname, "../public/newEntry.html"));
  });

app.post("/submit", async (req, res) => {
    const newBuilding = createBuildingData(building,state,city,builtin,builtby,imgurl);
    res.send(`<h1>Building:</h1><h2>${building} added✌️</h2><img src = ${imgurl} alt= "building">`);
  });
  
app.post("/search",  (req, res) => {
  searchResults = searchBuilding(req.body["search_query"]);
  console.log(req.body["search_query"]);
  res.sendFile(path.join(__dirname, "../public/search.html"));
  // res.sendStatus(200);
});

console.log(searchResults);

// Serve the variable to the frontend
app.get('/search_results', (req, res) => {
  res.json({ searchResults });
});

// app.put("/user/angela", (req, res) => {
//   res.sendStatus(200);
// });

// app.patch("/user/angela", (req, res) => {
//   res.sendStatus(200);
// });

// app.delete("/user/angela", (req, res) => {
//   //Deleting
//   res.sendStatus(200);
//}
// );

app.get('/', (req, res) => {
  throw new Error('BROKEN') // Express will catch this on its own.
});

app.listen(port, () => {
  console.log(`Server running on port ${port}.`);
});
